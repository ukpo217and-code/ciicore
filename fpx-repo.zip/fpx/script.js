/* =========================================================
   FARMERPULSE INTENT EXCHANGE — CLIENT LOGIC
   NOTE: This front end simulates a live exchange client-side.
   In production this data streams from Supabase Realtime /
   Postgres subscriptions + Edge Functions (see README).
   ========================================================= */
(function(){
  "use strict";

  /* ---------- DATA ---------- */
  const COMMODITIES = ["White Maize","Yellow Maize","Soybeans","Cassava","Sesame","Cocoa","Rice (Paddy)","Tomatoes","Groundnut","Ginger","Cashew","Cowpea","Sorghum","Millet","Palm Oil"];
  const STATES = ["Kaduna","Benue","Kano","Niger","Kogi","Oyo","Katsina","Kwara","Plateau","Enugu","Taraba","Adamawa","Ogun","Sokoto","Borno","Bauchi","Cross River","Ekiti","Nasarawa","Zamfara","Gombe","Yobe","Delta","Rivers"];
  const INTENTS = [
    {key:"buy", label:"Buy", color:"var(--orange)"},
    {key:"sell", label:"Sell", color:"var(--fresh-green)"},
    {key:"finance-need", label:"Need Finance", color:"var(--purple)"},
    {key:"finance-offer", label:"Offer Finance", color:"var(--purple)"},
    {key:"transport-need", label:"Need Transport", color:"var(--blue)"},
    {key:"transport-offer", label:"Transport Available", color:"var(--blue)"},
    {key:"storage-need", label:"Need Storage", color:"var(--blue)"},
    {key:"storage-offer", label:"Storage Available", color:"var(--blue)"},
    {key:"processing-need", label:"Need Processing", color:"var(--orange)"},
    {key:"processing-offer", label:"Processing Available", color:"var(--fresh-green)"},
    {key:"inputs-need", label:"Need Inputs", color:"var(--orange)"},
    {key:"inputs-offer", label:"Input Suppliers", color:"var(--fresh-green)"},
    {key:"labour-need", label:"Need Labour", color:"var(--orange)"},
    {key:"labour-offer", label:"Workers Available", color:"var(--fresh-green)"},
    {key:"training-need", label:"Need Training", color:"var(--blue)"},
    {key:"training-offer", label:"Training Providers", color:"var(--blue)"},
    {key:"extension", label:"Need Extension", color:"var(--blue)"},
    {key:"extension-offer", label:"Extension Officers", color:"var(--blue)"},
    {key:"insurance", label:"Insurance", color:"var(--purple)"},
    {key:"weather", label:"Weather", color:"var(--blue)"},
    {key:"export", label:"Export", color:"var(--orange)"},
    {key:"partnerships", label:"Partnerships", color:"var(--purple)"},
    {key:"government", label:"Government", color:"var(--deep-green)"},
    {key:"ngos", label:"NGOs", color:"var(--fresh-green)"}
  ];
  const ICONS = {buy:"🛒",sell:"🌾","finance-need":"💰","finance-offer":"🏦","transport-need":"🚚","transport-offer":"🚜","storage-need":"📦","storage-offer":"🏬","processing-need":"⚙️","processing-offer":"🏭","inputs-need":"🌱","inputs-offer":"🧪","labour-need":"👷","labour-offer":"🧑‍🌾","training-need":"🎓","training-offer":"📘",extension:"🧭","extension-offer":"🛰️",insurance:"🛡️",weather:"🌦️",export:"🚢",partnerships:"🤝",government:"🏛️",ngos:"❤️"};

  function rand(arr){return arr[Math.floor(Math.random()*arr.length)];}
  function randInt(min,max){return Math.floor(Math.random()*(max-min+1))+min;}

  const feedTemplates = [
    (c,s,q)=>`Buyer seeks ${q} MT ${c} — ${s}`,
    (c,s,q)=>`Cooperative selling ${q} MT ${c} — ${s}`,
    (c,s)=>`Tractor available — ${s}`,
    (c,s)=>`NGO seeking women farmers — ${s}`,
    (c,s)=>`Processor needs fresh ${c} — ${s}`,
    (c,s,q)=>`Exporter requesting ${q} MT export-grade ${c} — ${s}`,
    (c,s)=>`Storage facility available — ${s}`,
    (c,s)=>`Bank offering input financing — ${s}`,
    (c,s,q)=>`Match completed: ${q} MT ${c} — ${s}`,
    (c,s)=>`Extension officer available for consult — ${s}`
  ];

  /* ---------- LIVE STATS ---------- */
  let stats = {
    intents: 12540, buyers: 4281, sellers: 6918, matches: 332, value: 2.4, states: 36
  };
  const statsBanner = document.getElementById("statsBanner");
  function renderStats(){
    statsBanner.innerHTML = `
      <div class="stat-item"><span class="stat-item__value" id="v-intents">${stats.intents.toLocaleString()}</span><span class="stat-item__label">Active Intents</span></div>
      <div class="stat-item"><span class="stat-item__value" id="v-buyers">${stats.buyers.toLocaleString()}</span><span class="stat-item__label">Buyers</span></div>
      <div class="stat-item"><span class="stat-item__value" id="v-sellers">${stats.sellers.toLocaleString()}</span><span class="stat-item__label">Sellers</span></div>
      <div class="stat-item"><span class="stat-item__value" id="v-matches">${stats.matches}</span><span class="stat-item__label">Matches Today</span></div>
      <div class="stat-item"><span class="stat-item__value" id="v-value">₦${stats.value.toFixed(1)}B</span><span class="stat-item__label">Market Value</span></div>
      <div class="stat-item"><span class="stat-item__value" id="v-states">${stats.states}</span><span class="stat-item__label">States Active</span></div>
    `;
  }
  renderStats();
  setInterval(()=>{
    stats.intents += randInt(1,6);
    if(Math.random()>.5) stats.buyers += randInt(0,2);
    if(Math.random()>.5) stats.sellers += randInt(0,2);
    if(Math.random()>.4) stats.matches += randInt(0,1);
    stats.value += Math.random()*0.004;
    renderStats();
  }, 3500);

  /* ---------- EXCHANGE TAPE ---------- */
  const tapeTrack = document.getElementById("tapeTrack");
  function buildTape(){
    let items = [];
    for(let i=0;i<24;i++){
      const c = rand(COMMODITIES), s = rand(STATES);
      const dir = Math.random()>0.5;
      const pct = (Math.random()*6+0.2).toFixed(1);
      items.push(`<span>${c} · ${s} <b class="${dir?'up':'down'}">${dir?'▲':'▼'} ${pct}%</b></span>`);
    }
    tapeTrack.innerHTML = items.join("");
  }
  buildTape();

  /* ---------- LIVE INTENT FEED ---------- */
  const feedList = document.getElementById("feedList");
  const feedColors = {0:"var(--orange)",1:"var(--fresh-green)",2:"var(--blue)",3:"var(--purple)",4:"var(--orange)",5:"var(--orange)",6:"var(--blue)",7:"var(--purple)",8:"var(--fresh-green)",9:"var(--blue)"};
  let feedItems = [];

  function makeFeedItem(secondsAgo){
    const tIdx = randInt(0,feedTemplates.length-1);
    const c = rand(COMMODITIES), s = rand(STATES), q = randInt(5,600);
    const text = feedTemplates[tIdx](c,s,q);
    return {text, color: feedColors[tIdx], ts: Date.now() - secondsAgo*1000};
  }

  function timeAgo(ts){
    const diff = Math.round((Date.now()-ts)/1000);
    if(diff < 5) return "Now";
    if(diff < 60) return `${diff} seconds ago`;
    const m = Math.floor(diff/60);
    return `${m} minute${m>1?"s":""} ago`;
  }

  function renderFeed(){
    feedList.innerHTML = feedItems.slice(0,8).map(item=>`
      <li class="feed-item">
        <span class="feed-item__dot" style="background:${item.color}"></span>
        <span class="feed-item__text">${item.text}</span>
        <span class="feed-item__time">${timeAgo(item.ts)}</span>
      </li>
    `).join("");
  }

  for(let i=0;i<8;i++) feedItems.push(makeFeedItem(randInt(10,600)));
  feedItems.sort((a,b)=>b.ts-a.ts);
  renderFeed();

  setInterval(()=>{
    feedItems.unshift(makeFeedItem(0));
    feedItems = feedItems.slice(0,8);
    renderFeed();
  }, 4200);
  setInterval(renderFeed, 1000); // keep "time ago" fresh

  /* ---------- BROWSE BY INTENT ---------- */
  const intentGrid = document.getElementById("intentGrid");
  intentGrid.innerHTML = INTENTS.map(i=>`
    <button class="intent-card" data-intent="${i.key}">
      <span class="intent-card__icon" style="background:${i.color}22;color:${i.color}">${ICONS[i.key]}</span>
      <span class="intent-card__label">${i.label}</span>
      <span class="intent-card__count">${randInt(80,3200).toLocaleString()} active</span>
    </button>
  `).join("");

  /* ---------- MAP ---------- */
  const mapGrid = document.getElementById("mapGrid");
  const mapDetail = document.getElementById("mapDetail");
  const mapTypes = [
    {key:"supply", color:"var(--fresh-green)"},
    {key:"demand", color:"var(--red)"},
    {key:"services", color:"var(--blue)"},
    {key:"finance", color:"var(--purple)"}
  ];
  const stateData = STATES.slice(0,18).map(s=>({
    name:s, type: rand(mapTypes), count: randInt(40,900)
  }));
  mapGrid.innerHTML = stateData.map((s,idx)=>`
    <button class="map-node" data-idx="${idx}">
      <span class="map-node__pulse" style="background:${s.type.color}"></span>
      <span class="map-node__name">${s.name}</span>
    </button>
  `).join("");
  mapGrid.addEventListener("click", (e)=>{
    const btn = e.target.closest(".map-node");
    if(!btn) return;
    document.querySelectorAll(".map-node").forEach(n=>n.classList.remove("active"));
    btn.classList.add("active");
    const s = stateData[+btn.dataset.idx];
    mapDetail.innerHTML = `
      <h4>${s.name} State</h4>
      <div class="map-detail__stat">${s.count} live opportunities · dominant signal: ${s.type.key}</div>
      <ul class="map-detail__list">
        ${Array.from({length:4}).map(()=>{
          const c = rand(COMMODITIES); const q = randInt(5,500);
          return `<li>${Math.random()>0.5?"Buyer seeks":"Seller offers"} ${q} MT ${c}</li>`;
        }).join("")}
      </ul>
    `;
  });

  /* ---------- OPPORTUNITY CARDS ---------- */
  const opportunityGrid = document.getElementById("opportunityGrid");
  const badges = [{k:"sell",l:"SELL",cls:"opp-badge--sell"},{k:"buy",l:"BUY",cls:"opp-badge--buy"}];
  function makeOppCard(){
    const b = rand(badges), c = rand(COMMODITIES), s = rand(STATES), q = randInt(3,500);
    return `
      <div class="opp-card">
        <div class="opp-card__top">
          <span class="opp-badge ${b.cls}">${b.l}</span>
          <span class="opp-card__verified">✓ Verified</span>
        </div>
        <div class="opp-card__title">${c}</div>
        <div class="opp-card__meta">
          <span>${q} MT</span><span>${s}</span><span>Available next week</span>
        </div>
        <div class="opp-card__footer">
          <span class="opp-card__time">Posted ${randInt(10,59)}s ago</span>
          <div class="opp-card__actions">
            <button title="Save">♡</button>
            <button title="Share">↗</button>
          </div>
        </div>
        <a href="#whatsapp" class="btn btn--whatsapp btn--block" style="margin-top:6px;">Chat on WhatsApp</a>
      </div>
    `;
  }
  opportunityGrid.innerHTML = Array.from({length:6}).map(makeOppCard).join("");

  /* ---------- CHARTS ---------- */
  const chartFont = {family:"'Space Grotesk','sans-serif'"};
  Chart.defaults.color = "#DDEEE3";
  Chart.defaults.font = chartFont;
  Chart.defaults.borderColor = "rgba(255,255,255,.12)";

  new Chart(document.getElementById("chartDemand"), {
    type:"bar",
    data:{ labels:["Maize","Soybeans","Rice","Tomatoes","Sesame"],
      datasets:[{ data:[920,740,610,540,410], backgroundColor:"#F08A24", borderRadius:6 }]},
    options:{ plugins:{legend:{display:false}}, scales:{ y:{beginAtZero:true, grid:{display:false}}, x:{grid:{display:false}} } }
  });
  new Chart(document.getElementById("chartSupply"), {
    type:"bar",
    data:{ labels:["Cassava","Maize","Cocoa","Groundnut","Cowpea"],
      datasets:[{ data:[860,700,590,480,360], backgroundColor:"#3FA34D", borderRadius:6 }]},
    options:{ plugins:{legend:{display:false}}, scales:{ y:{beginAtZero:true, grid:{display:false}}, x:{grid:{display:false}} } }
  });
  new Chart(document.getElementById("chartValue"), {
    type:"line",
    data:{ labels:["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
      datasets:[{ data:[180,210,195,240,260,300,332], borderColor:"#5FD98A", backgroundColor:"rgba(95,217,138,.15)", fill:true, tension:.4 }]},
    options:{ plugins:{legend:{display:false}}, scales:{ y:{beginAtZero:true, grid:{color:"rgba(255,255,255,.08)"}}, x:{grid:{display:false}} } }
  });
  new Chart(document.getElementById("chartGrowth"), {
    type:"line",
    data:{ labels:["W1","W2","W3","W4","W5","W6"],
      datasets:[
        { label:"Buyers", data:[2800,3100,3400,3700,4000,4281], borderColor:"#F08A24", tension:.4 },
        { label:"Sellers", data:[4200,4700,5300,5900,6400,6918], borderColor:"#3FA34D", tension:.4 }
      ]},
    options:{ plugins:{legend:{position:"bottom",labels:{boxWidth:10}}}, scales:{ y:{grid:{color:"rgba(255,255,255,.08)"}}, x:{grid:{display:false}} } }
  });

  document.getElementById("rankStates").innerHTML = ["Kaduna","Kano","Benue","Niger","Kogi"].map(s=>`<li>${s}<span>${randInt(400,1200)}</span></li>`).join("");
  document.getElementById("rankGrowth").innerHTML = ["Sesame","Ginger","Cashew","Cowpea","Cocoa"].map(s=>`<li>${s}<span>+${randInt(20,60)}%</span></li>`).join("");

  /* ---------- ORGANIZATIONS ---------- */
  const orgTypes = ["Buyers","Processors","Exporters","Banks","Insurance","Governments","NGOs","Cooperatives"];
  const orgTabs = document.getElementById("orgTabs");
  orgTabs.innerHTML = orgTypes.map((t,i)=>`<button class="org-tab ${i===0?'active':''}" data-t="${t}">${t}</button>`).join("");
  const orgColors = ["#0B3D2E","#2E7D32","#2563EB","#F08A24","#7C4DFF","#D6362B"];
  function orgSample(type){
    const names = {
      "Buyers":["AgriSource Ltd","Northern Grains Co","FreshHarvest Foods"],
      "Processors":["Golden Mills","AgroProcess Nigeria","Savannah Foods"],
      "Exporters":["NaijaExport Traders","West Africa Commodities","Terra Exports"],
      "Banks":["Bank of Agriculture","AgriFinance Bank","Rural Credit Union"],
      "Insurance":["FarmGuard Insurance","AgroShield Assurance"],
      "Governments":["Federal Ministry of Agriculture","Kaduna State ADP"],
      "NGOs":["AgriGrowth Foundation","Women in Farming Initiative"],
      "Cooperatives":["Benue Farmers Co-op","Kano Grain Growers Union"]
    };
    return names[type] || names["Buyers"];
  }
  function renderOrgs(type){
    const orgGrid = document.getElementById("orgGrid");
    orgGrid.innerHTML = orgSample(type).map((n,i)=>`
      <div class="org-card">
        <div class="org-card__logo" style="background:${orgColors[i%orgColors.length]}">${n.split(" ").map(w=>w[0]).slice(0,2).join("")}</div>
        <div class="org-card__name">${n}</div>
        <div class="org-card__type">${type.slice(0,-1)} · Verified</div>
      </div>
    `).join("");
  }
  renderOrgs(orgTypes[0]);
  orgTabs.addEventListener("click",(e)=>{
    const btn = e.target.closest(".org-tab");
    if(!btn) return;
    orgTabs.querySelectorAll(".org-tab").forEach(b=>b.classList.remove("active"));
    btn.classList.add("active");
    renderOrgs(btn.dataset.t);
  });

  /* ---------- SUCCESS STORIES ---------- */
  const storyGrid = document.getElementById("storyGrid");
  const stories = [
    {quote:"“I typed one WhatsApp message about my cassava. Three days later, a processor in Ibadan bought all of it.”",path:["Conversation","Intent: Sell","Match","Trade Closed"],impact:"₦480,000 earned · 4 days",who:"Amina, Cassava Farmer — Ogbomoso"},
    {quote:"“We needed 300MT of soybeans fast. FarmerPulse matched us with two verified cooperatives the same week.”",path:["Conversation","Intent: Buy","Match","Trade Closed"],impact:"300 MT sourced · 6 days",who:"Procurement Lead — Northern Grains Co"},
    {quote:"“A tractor request I posted casually on WhatsApp turned into a standing contract with three farms nearby.”",path:["Conversation","Intent: Transport","Match","Ongoing Contract"],impact:"3 farms served monthly",who:"Yusuf, Equipment Owner — Lokoja"}
  ];
  storyGrid.innerHTML = stories.map(s=>`
    <div class="story-card">
      <div class="story-card__path">${s.path.map(p=>`<span>${p}</span>`).join("")}</div>
      <div class="story-card__quote">${s.quote}</div>
      <div class="story-card__impact">${s.impact}</div>
      <div class="story-card__who">${s.who}</div>
    </div>
  `).join("");

  /* ---------- PUBLIC STATS ---------- */
  const publicStatsGrid = document.getElementById("publicStatsGrid");
  const pStats = [
    ["Registered Farmers","218,400"],["Organizations","3,120"],["Buyers","4,281"],["Sellers","6,918"],
    ["Daily Conversations","41,900"],["Daily Intents","9,650"],["Successful Matches","112,300"],
    ["Est. Transaction Value","₦2.4B / day"],["Communities Covered","1,840"],["States Covered","36"]
  ];
  publicStatsGrid.innerHTML = pStats.map(([l,v])=>`
    <div class="pstat"><span class="pstat__value">${v}</span><span class="pstat__label">${l}</span></div>
  `).join("");

  /* ---------- FUTURE MODULES ---------- */
  const futureGrid = document.getElementById("futureGrid");
  const future = ["Marketplace","Finance","Insurance","Weather","Extension","Training","Export","Government Programs","NGO Opportunities","Traceability","Certification","Carbon Markets","Digital Identity","Marketplace API","Intelligence API"];
  futureGrid.innerHTML = future.map(f=>`<div class="future-chip">${f}</div>`).join("");

  /* ---------- HERO SEARCH CHIPS ---------- */
  const heroInput = document.getElementById("heroSearchInput");
  document.getElementById("searchHints").addEventListener("click",(e)=>{
    const chip = e.target.closest(".chip");
    if(!chip) return;
    heroInput.value = chip.dataset.q;
    heroInput.focus();
  });
  document.getElementById("heroSearchForm").addEventListener("submit",(e)=>{
    e.preventDefault();
    document.getElementById("search").scrollIntoView({behavior:"smooth"});
  });

  /* ---------- POST INTENT (opens WhatsApp flow section) ---------- */
  function goToWhatsAppFlow(){ document.getElementById("whatsapp").scrollIntoView({behavior:"smooth"}); }
  document.getElementById("postIntentBtn")?.addEventListener("click", goToWhatsAppFlow);
  document.getElementById("postIntentBtnMobile")?.addEventListener("click", goToWhatsAppFlow);

  /* ---------- DARK MODE ---------- */
  const darkToggle = document.getElementById("darkToggle");
  const root = document.documentElement;
  function applyTheme(t){ root.setAttribute("data-theme", t); localStorage_safe_set(t); }
  function localStorage_safe_set(t){ try{ /* not used in artifacts sandbox but safe no-op here */ }catch(e){} }
  darkToggle.addEventListener("click", ()=>{
    const cur = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
    applyTheme(cur);
  });
  if(window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches){
    applyTheme("dark");
  }

  /* ---------- MOBILE NAV HAMBURGER ---------- */
  const hamburger = document.getElementById("hamburger");
  const mainNav = document.getElementById("mainNav");
  hamburger.addEventListener("click", ()=>{
    const isOpen = mainNav.style.display === "flex";
    mainNav.style.display = isOpen ? "" : "flex";
    mainNav.style.cssText += isOpen ? "" : "position:absolute;top:76px;left:0;right:0;background:var(--surface);flex-direction:column;padding:20px 24px;border-bottom:1px solid var(--border);";
  });

  /* ---------- AI ASSISTANT ---------- */
  const aiAssistant = document.getElementById("aiAssistant");
  const aiToggle = document.getElementById("aiToggle");
  const aiClose = document.getElementById("aiClose");
  const aiBody = document.getElementById("aiBody");
  const aiForm = document.getElementById("aiForm");
  const aiInput = document.getElementById("aiInput");
  const aiSuggestions = document.getElementById("aiSuggestions");

  aiToggle.addEventListener("click", ()=> aiAssistant.classList.toggle("open"));
  aiClose.addEventListener("click", ()=> aiAssistant.classList.remove("open"));

  function aiRespond(q){
    const lower = q.toLowerCase();
    let reply;
    if(lower.includes("soybean")) reply = `There are currently ${randInt(80,300)} active soybean buyers, concentrated in Benue, Niger, and Kaduna. Want me to filter by verified only?`;
    else if(lower.includes("cassava")) reply = `${randInt(40,180)} cassava-related intents were posted today — mostly sell listings from Oyo and Ogun, and processor demand from Kano.`;
    else if(lower.includes("export")) reply = `Export-grade demand is currently highest for Sesame, Cocoa, and Cashew. ${randInt(10,60)} export opportunities are live now.`;
    else if(lower.includes("tractor")) reply = `${randInt(15,90)} tractor and equipment listings are active. The nearest available ones are in Lokoja, Ilorin, and Minna.`;
    else if(lower.includes("demand")) reply = `Right now, White Maize leads platform demand, followed closely by Soybeans and Tomatoes.`;
    else reply = `Searching the exchange for "${q}"… I found ${randInt(20,400)} matching intents across ${randInt(3,12)} states. Try narrowing by location or commodity for a tighter match.`;
    return reply;
  }
  function addAiMsg(text, who){
    const div = document.createElement("div");
    div.className = `ai-msg ai-msg--${who}`;
    div.textContent = text;
    aiBody.appendChild(div);
    aiBody.scrollTop = aiBody.scrollHeight;
  }
  aiForm.addEventListener("submit",(e)=>{
    e.preventDefault();
    const q = aiInput.value.trim();
    if(!q) return;
    addAiMsg(q,"user");
    aiInput.value = "";
    setTimeout(()=>addAiMsg(aiRespond(q),"bot"), 500);
  });
  aiSuggestions.addEventListener("click",(e)=>{
    const btn = e.target.closest("button");
    if(!btn) return;
    const q = btn.textContent;
    addAiMsg(q,"user");
    setTimeout(()=>addAiMsg(aiRespond(q),"bot"), 500);
  });

  /* ---------- BOTTOM NAV ACTIVE STATE ---------- */
  const bottomNavItems = document.querySelectorAll(".bottom-nav__item[href]");
  bottomNavItems.forEach(item=>{
    item.addEventListener("click", ()=>{
      bottomNavItems.forEach(i=>i.classList.remove("active"));
      item.classList.add("active");
    });
  });

})();
