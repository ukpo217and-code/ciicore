# FarmerPulse Intent Exchange (FPX) — Front-End Prototype

This is a fully responsive, production-styled front end for the FarmerPulse
Intent Exchange concept: `index.html` + `styles.css` + `script.js`, no build
step required. Open `index.html` in a browser, or host the three files on
any static host.

## What's real vs. simulated here

Because this is a static prototype (no server), the "live" exchange —
ticker tape, feed, stats, map, dashboard — is generated and animated
client-side with randomized sample data, on realistic intervals, so you can
evaluate the exact look, feel, and motion of the real thing.

## Wiring it to a real backend

The brief's target stack maps cleanly onto this UI:

- **Data model**: a Postgres `intents` table (intent type, commodity,
  quantity, unit, location, quality tags, price, verification status,
  visibility: private/partners/public, created_at) plus `organizations`,
  `matches`, and `conversations` tables in Supabase.
- **Realtime feed / ticker / stats banner**: subscribe to
  `supabase.channel('intents').on('postgres_changes', ...)` and prepend new
  rows into the same render functions already in `script.js`
  (`feedItems.unshift(...)`, `renderStats()`), replacing the `setInterval`
  simulators.
- **WhatsApp intake**: WhatsApp Cloud API webhook → Edge Function → OpenAI
  extraction (intent, commodity, qty, location, date) → confirm visibility
  with the user in-chat → insert into `intents` with the chosen visibility.
  Public rows immediately reach the site through the same Realtime channel.
- **Search**: Postgres full-text + column filters for the advanced search
  form; the AI assistant panel can call an Edge Function that does
  retrieval over `intents` plus a market-intelligence summary table.
- **Map**: swap the simplified state-node grid for a real Nigeria GeoJSON
  layer (e.g. via a lightweight mapping library), colored by the same
  supply/demand/services/finance signal already used here.
- **Dashboard charts**: same Chart.js calls, fed by materialized views
  (top commodities, growth, active states) refreshed by a scheduled Edge
  Function.
- **Auth & profiles**: Supabase Auth for organization/user accounts backing
  the "Featured Organizations" and future "Profile" tab.

## Notes on the map

The brief asks for a live heat map of Nigeria. This prototype represents
it as an interactive state-node grid (same data and interaction model —
click a state, see live opportunities) rather than a literal SVG
choropleth, since a geographically accurate map is best wired to a real
mapping library once live geodata is available.
